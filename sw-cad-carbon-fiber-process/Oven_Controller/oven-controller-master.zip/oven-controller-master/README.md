oven-controller
===============

For the composites oven team at Portland State. 

v0 - the original schematic representation of the current working breadboard setup.

v1 - the finished Arduino shield version on a printed circuit board. this works! 

v2 - additions to the v1 Arduino shield design
